from PyQt5.QtCore import Qt

from internal.custom_widget import CustomWidget
from internal.logger import Logger


class MFC(CustomWidget):
    def __init__(self, pos, cmd, key , parent):
        ratio = (0.1, 0.12)
        self.offset = 0
        self.key = key
        self.cmd = cmd
        self.value = 0
        self.parent = parent
        super().__init__(parent.translator, pos, ratio, "#B4C7E7")
        self.create_labels(key)
        

    def create_labels(self,key):
        """
        Creates labels for the FourWay widget.

        Args:
        - key: a string representing the key of the widget
        """
        self.create_label(key, alignment=Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)
        self.create_label_with_spin_box("setpoint", initial_value=0, max_value=self.parent.config.get_constant_value(key), unit="sccm", function=self.update_AO)
        self.create_label("actual", value = "0", unit = "sccm")
        self.create_label_with_spin_box("offset", unit="sccm", initial_value=0, min_value = -100, max_value=100, function=self.update_offset)
        self.create_label("size", value = self.parent.config.get_constant_value(key), unit="sccm")


    def update_AI(self, value):
        """
        Updates the value of the label.
        """
        value = (float(value)/5*self.parent.config.get_constant_value(self.key))
        self.value = int(round(value - self.offset))
        self.update_label("actual", value = self.value, unit="sccm")

    def update_AO(self, spin_box):
        """
        Updates the value of the label.
        """
        value = spin_box.value()/self.parent.config.get_constant_value(self.key)*5 #transform value to 0-5V
        self.parent.serial_reader.send_data(self.cmd, value)  
        Logger.debug(f"{self.key} setpoint changed to {spin_box.value()}")

    def update_offset(self, spin_box):
        """
        Updates the value of the label.
        """
        Logger.debug(f"{self.key} offset changed to {spin_box.value()}")
        self.offset = spin_box.value()

    def set_value(self, value):
        '''
        Sets the value of the MFC. Used in recipes
        '''
        #change value of spinbox
        for spin_box, spin_box_key, _, spin_box_kwargs in self.spin_boxes:
            if spin_box_key == "setpoint":
                spin_box.setValue(value)
                self.update_AO(spin_box)
                break

    def get_value(self):
        '''
        Gets the value of the MFC. Used in recipes
        '''
        return self.value