from PyQt5.QtCore import Qt

from internal.custom_widget import CustomWidget
from internal.logger import Logger


class Generator(CustomWidget):
    def __init__(self, pos, cmd, key , parent):
        ratio = (0.1, 0.15)
        self.serial_reader = parent.serial_reader

        self.key = key
        self.cmd = cmd
        self.state = False

        self.interlock_state = False
        self.source_value = 0
        self.voltage_reflected = 0

        self.parent = parent
        super().__init__(parent.translator, pos, ratio, "#B4C7E7")
        self.create_labels(key)
        self.create_buttons()

    def create_labels(self,key):
        """
        Creates labels for the Generator widget.

        Args:
        - key: a string representing the key of the widget
        """
        self.create_label(key, alignment=Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)
        self.create_label_with_spin_box("setpoint", initial_value=0, max_value=self.parent.config.get_constant_value(self.key), unit="V", function=self.update_AO)
        self.create_label("source_power", value = "0", unit = "V")
        self.create_label("voltage_reflected", value = "0", unit = "V")

    def create_buttons(self):
        """
        Creates buttons for the Generator widget.
        """
        self.create_button("interlock_state", function=self.click_interlock, state="off")
        self.create_button("set_state", function=self.click_on_off, state="disabled")
        self.create_button("Config", function=self.config)

    def interlock(self, new_state=None):
        '''
        Updates the interlock state
        '''
        if self.serial_reader.ser is not None:
            if new_state is not None:
                self.interlock_state = new_state
            else:
                self.interlock_state = not self.interlock_state
            self.serial_reader.write_data(self.cmd.Interlock, self.interlock_state)
            self.update_button("interlock_state", state = "on" if self.interlock_state else "off")

    def click_interlock(self):
        self.interlock()

    def on_off(self, new_state=None):
        '''
        Turns the generator on or off
        '''
        if self.serial_reader.ser is not None:
            if new_state is not None:
                self.state = new_state
            else:
                self.state = not self.state
            print(new_state)
            print(self.state)
            self.serial_reader.write_data(self.cmd.Enable, not self.state)
            self.update_button("set_state", state = "enabled" if self.state else "disabled")

    def click_on_off(self):
        self.on_off()



    def config(self):
        pass

    def update_AI(self, value):
        """
        Updates the value of the label.
        """
        self.source_value = (float(value[0])/10*self.parent.config.get_constant_value(self.key))
        self.voltage_reflected = (float(value[1])/10*self.parent.config.get_constant_value(self.key))
        self.update_label("source_power", value = self.source_value, unit = "V")
        self.update_label("voltage_reflected", value = self.voltage_reflected, unit = "V")

    def update_AO(self, spin_box):
        """
        Updates the value of the label.
        """
        value = spin_box.value()/self.parent.config.get_constant_value(self.key)*10 #transform value to 0-10V
        self.parent.serial_reader.send_data(self.cmd.AO, value)  
        Logger.debug(f"{self.key} setpoint changed to {spin_box.value()}")

    def update_offset(self, spin_box):
        """
        Updates the value of the label.
        """
        Logger.debug(f"{self.key} offset changed to {spin_box.value()}")
        self.offset = spin_box.value()

    def set_value(self, value):
        '''
        Sets the value of the MFC. Used in recipes
        '''
        #change value of spinbox
        for spin_box, spin_box_key, _, spin_box_kwargs in self.spin_boxes:
            if spin_box_key == "setpoint":
                spin_box.setValue(value)
                self.update_AO(spin_box)
                break

    def get_value(self):
        '''
        Gets the value of the MFC. Used in recipes
        '''
        return self.source_value
    
    